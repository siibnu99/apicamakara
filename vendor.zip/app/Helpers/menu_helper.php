<?php
function url()
{
    $url = [
        ['Dashboard', 'dashboard', 'fa-tachometer-alt'],
        ['Blog', 'blog', 'fa-book'],
        ['Kategori', 'category', 'fa-book'],
    ];
    return $url;
}
