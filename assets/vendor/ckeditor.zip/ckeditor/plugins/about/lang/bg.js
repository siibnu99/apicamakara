﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'bg', {
	copy: 'Авторско право &copy; $1. Всички права запазени.',
	dlgTitle: 'Относно CKEditor 4',
	moreInfo: 'За лицензионна информация моля посетете сайта ни:'
} );
